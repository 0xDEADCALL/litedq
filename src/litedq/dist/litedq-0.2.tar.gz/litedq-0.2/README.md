# Lite DQ
